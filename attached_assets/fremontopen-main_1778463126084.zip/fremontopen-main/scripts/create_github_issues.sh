#!/usr/bin/env bash
#
# Bulk-create GitHub Issues for the CueStats / Fremont Open backlog.
#
# Requirements:
#   - GitHub CLI installed:   https://cli.github.com/
#   - Authenticated:          gh auth login
#   - You must have push/Issues access to the target repo.
#
# Usage:
#   bash scripts/create_github_issues.sh                # uses default REPO
#   REPO=subiki/fremontopen bash scripts/create_github_issues.sh
#   DRY_RUN=1 bash scripts/create_github_issues.sh      # preview only
#
# The script is idempotent-ish: it checks for an issue with the same title and
# skips creation if found.

set -euo pipefail

REPO="${REPO:-subiki/fremontopen}"
DRY_RUN="${DRY_RUN:-0}"

if ! command -v gh >/dev/null 2>&1; then
  if [[ "$DRY_RUN" != "1" ]]; then
    echo "error: 'gh' (GitHub CLI) is not installed. See https://cli.github.com/" >&2
    exit 1
  fi
  echo "warning: 'gh' not installed — DRY_RUN mode, continuing." >&2
fi

if [[ "$DRY_RUN" != "1" ]]; then
  gh auth status >/dev/null 2>&1 || {
    echo "error: not authenticated. Run 'gh auth login' first." >&2
    exit 1
  }
fi

ensure_label() {
  local name="$1" color="$2" desc="$3"
  if [[ "$DRY_RUN" == "1" ]]; then
    echo "DRY: ensure label '$name'"
    return
  fi
  gh label create "$name" --repo "$REPO" --color "$color" --description "$desc" --force >/dev/null 2>&1 || true
}

# Priority + effort + epic labels
ensure_label "P0"        "B60205" "Ship next"
ensure_label "P1"        "D93F0B" "Near-term"
ensure_label "P2"        "FBCA04" "Nice-to-have"
ensure_label "P3"        "C2E0C6" "Someday"
ensure_label "effort: S" "BFD4F2" "≤ 1 day"
ensure_label "effort: M" "5319E7" "1–3 days"
ensure_label "effort: L" "0E8A16" "> 3 days"
ensure_label "epic: tournaments"  "1D76DB" "Tournament views & history"
ensure_label "epic: players"      "0E8A16" "Player profiles & ratings"
ensure_label "epic: ai"           "5319E7" "AI agent features"
ensure_label "epic: community"    "E99695" "Engagement & community"
ensure_label "epic: admin"        "FEF2C0" "Admin & data quality"
ensure_label "epic: charts"       "BFDADC" "Visualizations"
ensure_label "epic: mobile-ux"    "C5DEF5" "Mobile & UX polish"
ensure_label "epic: seasons"      "D4C5F9" "Series, seasons, league"
ensure_label "epic: integrations" "F9D0C4" "External integrations"
ensure_label "epic: platform"     "BFD4F2" "Platform & scaling"
ensure_label "epic: business"     "FBCA04" "Monetization"

create_issue() {
  local title="$1"
  local body="$2"
  shift 2
  local labels=("$@")

  if [[ "$DRY_RUN" == "1" ]]; then
    echo "DRY: would create issue [$title] labels=${labels[*]}"
    return
  fi

  # Skip if issue with identical title already exists
  local existing
  existing=$(gh issue list --repo "$REPO" --state all --search "in:title \"$title\"" --json title --jq '.[].title' | grep -Fx "$title" || true)
  if [[ -n "$existing" ]]; then
    echo "skip (exists): $title"
    return
  fi

  local label_args=()
  for l in "${labels[@]}"; do
    label_args+=(--label "$l")
  done

  gh issue create --repo "$REPO" \
    --title "$title" \
    --body "$body" \
    "${label_args[@]}" \
    >/dev/null
  echo "created: $title"
}

# ---- EPIC 1: Tournaments ----
create_issue "Bracket visualization on tournament detail" \
"Render winners/losers brackets for double-elim tournaments. Single-elim simpler. Stretch: live highlight of in-progress matches.

Acceptance:
- /tournaments/:id shows a bracket view alongside the matches table
- Single & double elimination supported
- Click a bracket match → scrolls to or opens the match in the table
" "P1" "effort: M" "epic: tournaments"

create_issue "Tournament timeline (Saturday-by-Saturday)" \
"List of past Saturdays with winner badge and quick stats.

Acceptance:
- New /timeline route (or section on Tournaments page)
- Each row: date, tournament name, winner, # matches, # players
- Sorted desc by date
" "P1" "effort: S" "epic: tournaments"

create_issue "Filter tournaments by game type" \
"Add a dropdown/segmented control to filter by 8-ball, 9-ball, snooker, one-pocket.

Acceptance:
- /tournaments page exposes ?game= query param
- Backend supports the filter (or it's client-side over the list)
" "P2" "effort: S" "epic: tournaments"

create_issue "Cinderella runs card (biggest seed upsets)" \
"Surface low-seeded players who beat high-seeded opponents.

Acceptance:
- Tournament detail shows a 'Notable Upsets' card if seeds available
- Sort by seed differential
" "P2" "effort: S" "epic: tournaments"

create_issue "Tournament archive search (date range, winner, format)" \
"Full-text + facet search across all tournaments.

Acceptance:
- /tournaments?from=YYYY-MM-DD&to=YYYY-MM-DD&winner=...&format=...
- UI filter bar on the Tournaments page
" "P2" "effort: M" "epic: tournaments"

create_issue "Printable bracket page" \
"Print-friendly CSS for the bracket view.

Acceptance:
- @media print rules hide sidebar/topbar and fit bracket on Letter/A4
- 'Print' button on tournament detail page
" "P3" "effort: S" "epic: tournaments"

# ---- EPIC 2: Players & Ratings ----
create_issue "Player alias / merge tool (same human, multiple names)" \
"Many tournaments have inconsistent name entry (Jim, Jimbo, Jim S.). Need a way for an admin to merge multiple Challonge participant names into one canonical player.

Acceptance:
- Admin UI to select multiple player records → merge into a canonical one
- Backend stores aliases array on the player doc
- AI agent and h2h aggregate use the canonical name
" "P0" "effort: M" "epic: players" "epic: admin"

create_issue "ELO / Glicko rating across all tournaments" \
"Compute a unified skill rating across every match in the cache.

Acceptance:
- Rating recomputed after each sync_job run
- Visible on player profile and as a leaderboard sort option
- Choose Glicko-2 (handles inactivity) over plain ELO
" "P1" "effort: M" "epic: players" "epic: charts"

create_issue "Player streaks (W/L/attendance)" \
"Show current win streak, loss streak, and consecutive-Saturdays-attended counter.

Acceptance:
- Player profile shows three streak chips
- Streaks computed from matches collection sorted by completed_at
" "P1" "effort: S" "epic: players"

create_issue "Player nicknames (admin-editable)" \
"Allow an admin to set a display nickname per player.

Acceptance:
- Admin form on player profile sets nickname
- Nickname shown in parentheses next to name across the app
" "P1" "effort: S" "epic: players" "epic: admin"

create_issue "Side-by-side compare page" \
"/compare/playerA/playerB shows stats, head-to-head record, common opponents.

Acceptance:
- New route with two player selectors
- Renders stats, h2h, shared opponents win-rate comparison
- Links from each player profile ('Compare with…')
" "P2" "effort: M" "epic: players"

create_issue "Player avatars / photos" \
"Admin upload of player photos. Use object storage.

Acceptance:
- Admin can upload an image per player
- Image shown on profile, leaderboard rows, and in chat citations
- Fallback to initials avatar if none
" "P2" "effort: M" "epic: players" "epic: admin"

create_issue "Game-type breakdown per player" \
"Player profile shows their 8-ball vs 9-ball vs snooker record.

Acceptance:
- Tab or section on profile with W-L by game type
- Powered by tournaments.game field aggregated against the player's matches
" "P2" "effort: S" "epic: players" "epic: charts"

create_issue "Custom cue / equipment listed on profile" \
"Optional admin-editable field on the player profile.

Acceptance:
- 'Cue' field on player edit form
- Displayed as a small chip on the profile
" "P3" "effort: S" "epic: players"

# ---- EPIC 3: AI ----
create_issue "Multi-session chat sidebar" \
"Persistent chat history sidebar with rename/delete/switch.

Acceptance:
- Sidebar lists session_ids with last-message preview
- New / rename / delete actions
- Active session highlighted
" "P1" "effort: S" "epic: ai"

create_issue "AI weekly recap auto-generation" \
"After each Saturday sync, generate a markdown recap and save as a 'post'.

Acceptance:
- sync_job.py optionally invokes Claude after a successful sync
- Stores a recap doc per tournament/week
- Dashboard shows 'Latest Recap' card
" "P1" "effort: M" "epic: ai" "epic: community"

create_issue "Alias resolution in AI chat" \
"After Epic 2.1 lands, the AI should resolve 'Jimmy' to the canonical player and consider all aliases.

Acceptance:
- The system prompt includes canonical + aliases for each player
- 'Who beat Jim the most?' returns same answer as 'Who beat Jimmy the most?'
" "P1" "effort: S" "epic: ai"

create_issue "Voice input for AI chat" \
"Web Speech API → existing /api/chat.

Acceptance:
- Microphone button in chat input
- Live transcription, submit on stop
- Graceful fallback when API unavailable
" "P2" "effort: M" "epic: ai" "epic: mobile-ux"

create_issue "AI predictive matchup" \
"Given two players, predict winner with reasoning grounded in past matches.

Acceptance:
- New /predict route OR a card on the compare page
- Returns a percentage and 2-3 sentence rationale
" "P2" "effort: S" "epic: ai"

create_issue "AI trash-talk generator" \
"Fun: 'Write a 100-word roast for Dr Seuss based on his record.'

Acceptance:
- Button on player profile (admin only? or public?) to generate trash talk
- Saves the latest one (with a 'regenerate' option)
" "P2" "effort: S" "epic: ai" "epic: community"

create_issue "Streaming responses for chat (SSE)" \
"Replace the request/response cycle with a streaming SSE so answers appear token-by-token.

Acceptance:
- /api/chat/stream SSE endpoint
- Frontend renders incrementally
" "P3" "effort: M" "epic: ai"

# ---- EPIC 4: Community ----
create_issue "Public shareable player card (/p/:name) with OG image" \
"Beautiful social-share preview when a player card link is posted to WhatsApp/Twitter.

Acceptance:
- /p/:name route renders a 1200x630 card image (server-rendered or canvas)
- OG meta tags point to the image
- 'Copy link' / 'Share' buttons on the profile
" "P1" "effort: M" "epic: community" "epic: business"

create_issue "Email digest after each Saturday tournament" \
"Resend integration. Subscribers get a recap email with winner, top matches, and AI summary.

Acceptance:
- /subscribe form (email only, no auth)
- sync_job.py triggers a mail-out after a tournament moves to 'complete'
- Unsubscribe link
" "P1" "effort: M" "epic: community" "epic: integrations"

create_issue "Weekly predictions board" \
"Anyone can claim a prediction for next Saturday ('I'll beat Jimmy').

Acceptance:
- /predictions page with simple name+prediction form (no auth, captcha or rate-limit)
- After sync, automatically marks each prediction as Hit/Miss
- Leaderboard of predictors
" "P2" "effort: M" "epic: community"

create_issue "Match comments" \
"Threaded comments on each match.

Acceptance:
- Comment form on match detail
- Stored in MongoDB, moderation flag
- Light HTML escape only
" "P2" "effort: M" "epic: community"

create_issue "Photo gallery per tournament" \
"Admin uploads, public viewing.

Acceptance:
- Admin upload UI on tournament detail
- Lightbox gallery for visitors
" "P2" "effort: M" "epic: community" "epic: admin"

create_issue "Rivalry of the week" \
"Auto-featured h2h pair on dashboard.

Acceptance:
- Algorithm picks the pair with most recent meetings + closest h2h record
- Shows recent results + AI blurb
" "P2" "effort: S" "epic: community" "epic: ai"

create_issue "MVP / Play of the Week voting" \
"Public vote per Saturday.

Acceptance:
- Voting page open Sunday–Wednesday after a tournament
- One vote per IP (best-effort)
- Result displayed on dashboard
" "P3" "effort: M" "epic: community"

create_issue "Achievement badges" \
"Gamification: 5-win streak, undefeated tournament, etc.

Acceptance:
- Badge engine evaluated after each sync
- Badges shown on profile
" "P3" "effort: S" "epic: community"

# ---- EPIC 5: Admin & Data Quality ----
create_issue "Single-admin auth (JWT)" \
"Protect future admin endpoints with JWT.

Acceptance:
- /api/admin/login with bcrypt-hashed password from .env
- Bearer-token middleware on all admin routes
- React admin login page
" "P0" "effort: M" "epic: admin"

create_issue "Manual data corrections UI" \
"Admin can edit names, fix scores, merge players.

Acceptance:
- /admin pages for tournaments, matches, players
- Edit form with audit log entries
- All edits gated behind admin JWT
" "P0" "effort: M" "epic: admin"

create_issue "Sync now (admin-only) endpoint" \
"Bring back a manual Sync Now — but only behind admin auth.

Acceptance:
- POST /api/admin/sync requires admin JWT
- UI button visible only when logged in as admin
" "P1" "effort: S" "epic: admin" "epic: platform"

create_issue "Player dedup suggestions (Levenshtein)" \
"Suggest likely-duplicate player records to admin.

Acceptance:
- Background job computes pairs with edit-distance ≤ 2 and ≥ 1 shared tournament
- Admin sees a 'Suggested merges' list
" "P1" "effort: M" "epic: admin" "epic: players"

create_issue "Match data validation" \
"Catch impossible scores (negative, race overshoots).

Acceptance:
- sync_job.py flags matches with invalid scores in a 'invalid_matches' collection
- Admin sees the list to review
" "P1" "effort: S" "epic: admin"

create_issue "Manual match entry for side games" \
"Admin can record a match that isn't in Challonge.

Acceptance:
- Admin form: tournament (or 'side-game'), two players, score, winner
- Surfaces in match history
" "P2" "effort: M" "epic: admin"

create_issue "Multi-Challonge-account sync" \
"Support multiple Challonge API keys, one per organizer.

Acceptance:
- Config supports CHALLONGE_API_KEYS (comma-separated)
- sync_job.py iterates each key
" "P2" "effort: M" "epic: admin" "epic: platform"

create_issue "Audit log of admin edits" \
"Track every admin change for transparency.

Acceptance:
- audit_log collection: who, what, when, before/after
- /admin/audit page shows recent edits
" "P2" "effort: S" "epic: admin"

# ---- EPIC 6: Charts ----
create_issue "Wins-over-time chart per player" \
"Line chart on player profile: cumulative wins per Saturday.

Acceptance:
- Use recharts
- X-axis: tournament date, Y-axis: cumulative wins
" "P1" "effort: S" "epic: charts" "epic: players"

create_issue "Player rating history chart" \
"After ELO/Glicko ships, plot rating over time.

Acceptance:
- Depends on Epic 2.2
- Line chart per player
" "P1" "effort: S" "epic: charts" "epic: players"

create_issue "Head-to-head heatmap matrix" \
"N×N grid of all players showing win-rates.

Acceptance:
- /h2h route
- Hover shows precise (w-l) for each cell
- Click a cell → compare page
" "P2" "effort: M" "epic: charts"

create_issue "Tournament difficulty indicator" \
"Show avg opponent rating per tournament.

Acceptance:
- Depends on Epic 2.2
- Displayed as a chip on tournament cards
" "P2" "effort: S" "epic: charts" "epic: tournaments"

create_issue "Geographic map of players" \
"If/when player location data exists, map them.

Acceptance:
- Optional 'home town' field on player
- /map route with simple Leaflet/Mapbox view
" "P3" "effort: S" "epic: charts" "epic: players"

# ---- EPIC 7: Mobile & UX ----
create_issue "PWA install (manifest + service worker)" \
"Make the site installable on iOS/Android.

Acceptance:
- manifest.json with icons
- Service worker caches static assets + last /api/stats response
- 'Install' prompt where supported
" "P1" "effort: S" "epic: mobile-ux"

create_issue "Sidebar collapse on mobile (hamburger + drawer)" \
"Currently sidebar is hidden < md. Add a hamburger menu for true mobile nav.

Acceptance:
- Hamburger button visible < md
- Tapping opens a drawer with the same nav links
" "P1" "effort: S" "epic: mobile-ux"

create_issue "Light mode toggle" \
"Currently dark-only. Add a light theme.

Acceptance:
- Toggle in sidebar footer or topbar
- Tailwind dark: classes applied
- Persisted in localStorage
" "P2" "effort: S" "epic: mobile-ux"

create_issue "Pinch-zoom on bracket view" \
"Bracket can be large; allow pinch/zoom on touch.

Acceptance:
- After Epic 1.1 lands, wrap bracket in a pan/zoom container
" "P2" "effort: S" "epic: mobile-ux" "epic: tournaments"

create_issue "Keyboard shortcuts" \
"Power-user nav: '/' search, 'g p' players, etc.

Acceptance:
- Shortcut dialog (cmd+/) lists them
- Implemented with a small hook
" "P3" "effort: S" "epic: mobile-ux"

# ---- EPIC 8: Seasons ----
create_issue "Season groupings with cumulative standings" \
"'2026 Spring' across N Saturdays — cumulative leaderboard.

Acceptance:
- seasons collection with date range
- /seasons and /seasons/:id pages
- Cumulative standings recomputed per sync
" "P1" "effort: M" "epic: seasons"

create_issue "Attendance tracker" \
"Who showed up each Saturday — visible streak counter per player.

Acceptance:
- Player profile shows attendance streak
- Season pages show attendance %
" "P2" "effort: M" "epic: seasons" "epic: players"

create_issue "Prize pool tracking per tournament + per-season totals" \
"Optional pot tracking.

Acceptance:
- Admin edits prize pool per tournament
- Aggregated per season + per player (wins by pot)
" "P2" "effort: S" "epic: seasons" "epic: admin"

create_issue "League-wide points system" \
"Configurable: 10 pts for 1st, 7 for 2nd, etc.

Acceptance:
- Admin configures point table per season
- Standings show points + wins
" "P3" "effort: M" "epic: seasons"

# ---- EPIC 9: Integrations ----
create_issue "iCal feed of upcoming Saturday tournaments" \
"Subscribe button → /api/calendar.ics for users' calendar apps.

Acceptance:
- /api/calendar.ics emits ICS for the next 8 Saturdays
- Marketing: 'Add to calendar' button on dashboard
" "P1" "effort: S" "epic: integrations"

create_issue "Discord webhook for results" \
"Post Saturday results to a Discord channel after sync.

Acceptance:
- DISCORD_WEBHOOK env var
- sync_job.py posts a formatted message
" "P2" "effort: S" "epic: integrations"

create_issue "Twitter/X auto-post of weekly winner" \
"Post the winner card to X after each Saturday.

Acceptance:
- X API v2 credentials in .env
- sync_job.py posts a tweet on tournament complete
" "P2" "effort: M" "epic: integrations" "epic: community"

create_issue "Resend email for digests & follow notifications" \
"Email subscribers about followed players + weekly digest.

Acceptance:
- Resend API integration
- Follow notification opt-in
- Weekly digest opt-in (separate)
" "P2" "effort: M" "epic: integrations" "epic: community"

create_issue "Stripe entry-fee registration for next Saturday" \
"Players pay entry fee online.

Acceptance:
- /register page for next tournament
- Stripe checkout
- Admin sees a list of paid registrants
" "P3" "effort: M" "epic: integrations" "epic: business"

create_issue "Google Calendar auto-create event for next tournament" \
"Once OAuth'd, auto-create events for admin's calendar.

Acceptance:
- Admin OAuths Google
- 'Create event' button on tournament admin page
" "P3" "effort: M" "epic: integrations"

# ---- EPIC 10: Platform ----
create_issue "SQLite migration path for shared-hosting deploys" \
"Optional storage backend so DreamHost shared can host this without Mongo.

Acceptance:
- Storage layer abstraction (Mongo vs SQLite via config)
- README updated with shared-hosting walkthrough
" "P1" "effort: M" "epic: platform"

create_issue "SSR / static export of player pages for SEO" \
"Render player and tournament pages as HTML for crawlers.

Acceptance:
- Build step generates /p/:name.html for every player after sync
- Search engines can index them
" "P1" "effort: S" "epic: platform"

create_issue "Leaderboard cache in sessionStorage" \
"Avoid re-fetching the full leaderboard on every Prev/Next click in player profile.

Acceptance:
- fetchLeaderboard result cached for the session
- Cache busted after a sync
" "P1" "effort: S" "epic: platform"

create_issue "Case-insensitive player URL matching" \
"/players/jimmy and /players/Jimmy should both work.

Acceptance:
- Backend looks up players with a case-insensitive index
" "P2" "effort: S" "epic: platform"

create_issue "API ETag + 304 support" \
"Add ETags on GET endpoints; clients cache between syncs.

Acceptance:
- Last-Modified or ETag header on read endpoints
- 304 returned when If-None-Match matches
" "P2" "effort: S" "epic: platform"

create_issue "Health check endpoint /api/health" \
"For uptime monitoring.

Acceptance:
- /api/health returns DB status + last sync age
- 200 on healthy, 503 on stale > 14 days
" "P2" "effort: S" "epic: platform"

create_issue "Backfill script for arbitrary historical Challonge tournament IDs" \
"Allow admin to import any historical bracket by ID.

Acceptance:
- sync_job.py --tournament <id> imports a single tournament
- Useful for one-time backfills
" "P2" "effort: M" "epic: platform" "epic: admin"

create_issue "Multi-tenant (host other tournaments alongside Fremont Open)" \
"Make the platform host multiple leagues.

Acceptance:
- Tenant scoping on every collection
- Subdomain routing or path-based
" "P3" "effort: L" "epic: platform"

# ---- EPIC 11: Business ----
create_issue "Sponsor slot on dashboard" \
"'This week sponsored by Talarico's' banner.

Acceptance:
- Admin configures sponsor name + logo + link
- Banner appears on dashboard
" "P2" "effort: S" "epic: business"

create_issue "Pro Shop affiliate links on player profiles" \
"Affiliate revenue from cue/chalk links.

Acceptance:
- Admin configures affiliate links per gear category
- 'Recommended cue' card on profile
" "P3" "effort: M" "epic: business"

create_issue "Premium tier (branded newsletter, custom subdomain)" \
"Paid tier for tournament organizers.

Acceptance:
- Stripe subscription
- White-label branding per tenant
" "P3" "effort: M" "epic: business" "epic: platform"

create_issue "Crowd-funding for tournament cash pots" \
"Let fans contribute to a player's prize pot.

Acceptance:
- Stripe Connect
- 'Sponsor a player' button on profile
" "P3" "effort: M" "epic: business"

echo ""
echo "All done. View issues: gh issue list --repo $REPO --limit 100"
